import '/flutter_flow/flutter_flow_util.dart';
import 'fotos_carousel_component_widget.dart' show FotosCarouselComponentWidget;
import 'package:flutter/material.dart';

class FotosCarouselComponentModel
    extends FlutterFlowModel<FotosCarouselComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
