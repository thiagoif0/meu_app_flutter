import '/flutter_flow/flutter_flow_util.dart';
import 'detalhes_cliente_page_widget.dart' show DetalhesClientePageWidget;
import 'package:flutter/material.dart';

class DetalhesClientePageModel
    extends FlutterFlowModel<DetalhesClientePageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
