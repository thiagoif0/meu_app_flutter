export 'foto_carousel_widget.dart' show FotoCarouselWidget;
