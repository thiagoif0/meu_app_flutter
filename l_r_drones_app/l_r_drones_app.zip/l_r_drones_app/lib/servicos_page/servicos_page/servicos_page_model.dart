import '/flutter_flow/flutter_flow_util.dart';
import 'servicos_page_widget.dart' show ServicosPageWidget;
import 'package:flutter/material.dart';

class ServicosPageModel extends FlutterFlowModel<ServicosPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
